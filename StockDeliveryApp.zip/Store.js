import {combineReducers, configureStore} from '@reduxjs/toolkit';
import {setupListeners} from '@reduxjs/toolkit/query';
import {VendorListsApi} from './src/features/api/distributor/VendorListAPISlice';
import {UsersApi} from './src/features/api/vendor/userAPISlice';
import {VendorOrdersAPI} from './src/features/api/vendor/vendorOrdersAPISlice';
import {VendorProductsApi} from './src/features/api/vendor/VendorProductsAPISlice';
import AuthSlice from './src/features/auth/AuthSlice';
import OrderManagerSlice from './src/features/orderManagement.js/OrderSlice';
import AddProductSlice from './src/features/product/AddProductSlice';
import VendorDistributorSlice from './src/features/vendorDistributor/VendorDistributorSlice';

const rootReducer = combineReducers({
  user: AuthSlice,
  add_product: AddProductSlice,
  vendor_distributor: VendorDistributorSlice,
  order_manager: OrderManagerSlice,
  [UsersApi.reducerPath]: UsersApi.reducer,
  [VendorProductsApi.reducerPath]: VendorProductsApi.reducer,
  [VendorListsApi.reducerPath]: VendorListsApi.reducer,
  [VendorOrdersAPI.reducerPath]: VendorOrdersAPI.reducer,
});

export const store = configureStore({
  reducer: rootReducer,
  middleware: getDefaultMiddleware =>
    getDefaultMiddleware().concat(
      UsersApi.middleware,
      VendorProductsApi.middleware,
      VendorListsApi.middleware,
      VendorOrdersAPI.middleware,
    ),
});

setupListeners(store.dispatch);
