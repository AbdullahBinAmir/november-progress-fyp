import { View, Text, TouchableOpacity, StyleSheet, Image } from 'react-native'
import React from 'react'
import { colors } from '../global/Styles'
import { useDispatch } from 'react-redux'
import { removeItem } from '../features/orderManagement.js/OrderSlice'
import { imageURL } from '../global/API_Source_URL'

const CartItemCard = ({id,image,name,qtyOrdered,salePrice}) => {

  const dispatch=useDispatch()

  return (
    <View style={styles.cartItem}>
    <View style={{flexDirection: 'row'}}>
      <Image
        source={{uri: imageURL+image}}
        style={{height: 80, width: 80}}
      />
      <View>
        <Text style={styles.cartItemText}>Name: {name}</Text>
        <Text style={styles.cartItemText}>Cartons: {qtyOrdered}</Text>
        <Text style={styles.cartItemText}>Item total: {salePrice*qtyOrdered} PKR</Text>
      </View>
    </View>
    <TouchableOpacity style={styles.delBtn}
        onPress={()=>dispatch(removeItem(id))}
    >
      <Text
        style={styles.delBtnText}>
        Remove from cart
      </Text>
    </TouchableOpacity>
  </View>
  )
}

export default CartItemCard

const styles = StyleSheet.create({
    cartItemText: {
      fontSize: 18,
      color: colors.grey2,
    },
    cartItem: {
      width: '90%',
      borderWidth: 2,
      alignSelf: 'center',
      padding: 5,
      borderColor: colors.buttons,
      borderRadius: 10,
      marginTop:10
    },
    delBtn: {
      borderWidth: 1,
      borderColor: colors.cardbackground,
      marginVertical: 5,
      marginHorizontal: 10,
      padding: 5,
      backgroundColor: '#EA3C53',
      borderRadius: 5,
    },
    delBtnText:{
      fontSize: 20,
      textAlign: 'center',
      color: colors.cardbackground,
      fontWeight:'bold'
    }
  });