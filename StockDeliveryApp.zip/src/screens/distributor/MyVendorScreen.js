import React, {useState, useEffect} from 'react';
import {
  Text,
  View,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
//import {myVendorsList} from '../../global/Distributor/MyVendors';
import UserInfoCard from '../../components/UserInfoCard';
import Icon from 'react-native-vector-icons/FontAwesome';
import {useSelector} from 'react-redux';
import {colors} from '../../global/Styles';
import {useGetVendorsQuery} from '../../features/api/distributor/VendorListAPISlice';
import MenuItem from '../../components/MenuItem';

export default function MyVendorScreen({navigation}) {
  //const dispatch = useDispatch();
  const {userInfo} = useSelector(state => state.user);
  //const {isLoading, vendorInfo} = useSelector(state => state.vendor_distributor);
  const {isLoading, data = []} = useGetVendorsQuery({id: userInfo.id});
  const [vendor, setVendor] = useState();
  const [vendorData, setVendorData] = useState();
  
  useEffect(() => {
    setVendor('');
  });

  //console.log(data)

  if (isLoading) {
    return (
      <View style={styles.loader}>
        <ActivityIndicator visible={true} />
      </View>
    );
  } else if (data) {
    return (
      <View style={styles.container}>
      <View style={styles.titleBar}>
      <View style={{flex: 0.2, marginLeft: 10, padding: 10}}>
        <Icon
          name="navicon"
          color={colors.cardbackground}
          size={30}
          onPress={() => {
            navigation.toggleDrawer();
          }}
        />
      </View>
      <View style={{flex: 0.6}}>
        <Text style={styles.titleText}> My Vendors </Text>
      </View>
      <View  style={{flex: 0.2}}>
        <MenuItem realData={data} setData={setVendorData} />
      </View>
    </View>
        <View style={{flex: 1, flexGrow: 1}}>
          <FlatList
            style={{marginTop: 10, marginBottom: 10}}
            horizontal={false}
            showsVerticalScrollIndicator={true}
            data={vendorData?vendorData:data}
            keyExtractor={(item, index) => index.toString()}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() =>
                  item.status === 'Allow'
                    ? navigation.navigate('MainOrderScreen',{data:data[0]})
                    : alert(
                        `Access denied because your current status is ${item.status}`,
                      )
                }>
                <UserInfoCard item={item} uid={item.uid} />
              </TouchableOpacity>
            )}
          />
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  loader: {
    flex: 1,
    justifyContent: 'center',
    textAlign: 'center',
    paddingTop: 30,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  container: {
    flex: 1,
    backgroundColor: colors.cardbackground,
  },
  textTop: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.buttons,
  },
  textBarTab: {
    alignItems: 'flex-start',
    justifyContent: 'center',
    marginLeft: 5,
    marginTop: 15,
    marginBottom: 10,
    height: 50,
    backgroundColor: colors.grey5,
    padding: 10,
    borderRadius: 10,
  },
  imgStyle: {
    width: 60,
    height: 50,
    borderRadius: 25,
  },
  cardText: {
    color: colors.grey2,
    fontSize: 18,
  },
  titleBar: {
    width: '100%',
    height: 80,
    backgroundColor: colors.buttons,
    flexDirection: 'row',
    alignItems: 'center',
    // justifyContent:'space-evenly',
    paddingHorizontal: 15,
  },
  titleText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.cardbackground,
  },
  menuView: {
    padding: 50,
    flexDirection: 'row',
    justifyContent: 'center',
    height: 200,
  },
});
